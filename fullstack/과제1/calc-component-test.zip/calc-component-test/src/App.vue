<script setup>
import Calc from './components/Calc.vue'
import Calc2 from './components/Calc2.vue'
import Calc3 from './components/Calc3.vue'
import Calc4 from './components/Calc4.vue'
import Calc5 from './components/Calc5.vue'
</script>

<template>
  <div>
    <h1>1번</h1>
    <Calc />
    <hr />
    <h1>2번</h1>
    <Calc2 />
    <hr />
    <h1>3번</h1>
    <Calc3 />
    <hr />
    <h1>4번</h1>
    <Calc4 />
    <hr />
    <h1>5번</h1>
    <Calc5 />
  </div>
</template>

<style scoped></style>
