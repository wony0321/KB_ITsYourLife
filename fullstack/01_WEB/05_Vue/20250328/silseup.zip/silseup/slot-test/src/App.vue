<script setup>
import NoSlotTest from './components/NoSlotTest.vue'
import SlotTest from './components/SlotTest.vue'
</script>

<template>
  <div>
    <NoSlotTest />
    <SlotTest />
  </div>
</template>

<style scoped></style>
