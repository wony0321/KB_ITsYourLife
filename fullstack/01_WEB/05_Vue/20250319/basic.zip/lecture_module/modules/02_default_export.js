/**
 * Default Export
 * - 모듈에서 단 하나의 값을 기본적으로 내보낼때 사용
 * - 가져올 때 이름을 자유롭게 지정 가능
 */

export default function add(x, y) {
  return x + y;
}
