import { add, multiply } from './modules/02-19-module.js';
import baseFunc from './modules/02-20-module.js';

console.log(add(4));
console.log(getBase());
console.log(baseFunc());
