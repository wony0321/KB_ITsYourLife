const hello = require('./hello');
const user = require('./user');

console.log(user);
console.log(hello);

hello(user);
