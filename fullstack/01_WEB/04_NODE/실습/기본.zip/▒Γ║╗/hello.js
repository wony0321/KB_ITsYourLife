// function hello(n) {
//   console.log(`${n}님, 안녕하세요?`);
// }

// hello('임예원');

const hello = (n) => {
  console.log(`${n}님, 안녕하세요?`);
};
module.exports = hello;
