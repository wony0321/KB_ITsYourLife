package org.scoula.jdbc_ex.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.scoula.jdbc_ex.common.JDBCUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ConnectionTest {

    @Test
    @DisplayName("DB 연결 테스트 결과")
    public void testConnection2() throws ClassNotFoundException {
        String url = "jdbc:mysql://localhost:3306/jdbc_ex";
        String username = "root";
        String password = "1234";

        Class.forName("com.mysql.cj.jdbc.Driver");

        try(Connection conn = DriverManager.getConnection(url, username, password)) {

            assertNotNull(conn, "연결 객체가 null입니다.");
            assertFalse(conn.isClosed(), "연결이 닫혀 있습니다.");

            System.out.println("연결 성공");

            JDBCUtil.closeConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
