package org.scoula.jdbc_ex.common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JDBCUtilTest {

    @Test
    void getConnection() {
    }

    @Test
    void closeConnection() {
    }
}